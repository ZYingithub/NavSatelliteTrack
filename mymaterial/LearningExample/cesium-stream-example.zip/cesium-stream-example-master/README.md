# cesium-stream-example

## Install Dependencies
```sh
npm install
```

## Run the server
```sh
node index.js
```

Then go to `localhost:3000`
